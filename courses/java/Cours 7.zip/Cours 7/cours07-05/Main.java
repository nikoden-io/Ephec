import java.util.*;

public class Main {
    private static Scanner s = new Scanner(System.in);


    public static void main(String[] args) {
        // Votre code doit être APRES de ce commentaire
        int[] numbers = {1, 2, 3, 5, 7, 10};
        int target;
        boolean isSolutionExisting = false;

        System.out.println("Entrez le nombre à atteindre :");
        target = s.nextInt();

        String[] operations = {"+", "-", "*", "/", "%"};


//        for (int i = 0; i < numbers.length; i++) {
//            for (int j = 0; j < numbers.length; j++) {
//                for (String op1 : operations) {
//                    for (String op2 : operations) {
//                        if (calculate(calculate(numbers[i], numbers[j], op1), numbers[j], op2) == target) {
//                            System.out.println(numbers[i] + " " + op1 + " " + numbers[j] + " " + op2 + " " + numbers[j] + " = " + target);
//                            isSolutionExisting = true;
//                        }
//                    }
//                }
//            }
//        }

        for (int i = 0; i < numbers.length; i++) {
            for (int j = 0; j < numbers.length; j++) {
                for (int k = 0; k < numbers.length; k++) {
                    for (String op1 : operations) {
                        for (String op2 : operations) {
                            for (String op3 : operations) {
                                if (calculate(calculate(calculate(numbers[i], numbers[j], op1), numbers[j], op2), numbers[k], op3) == target) {
                                    System.out.println(numbers[i] + " " + op1 + " " + numbers[j] + " " + op2 + " " + numbers[j] + " " + op3 + " " + numbers[k] + " = " + target);
                                    isSolutionExisting = true;
                                }
                            }
                        }
                    }
                }
            }
        }


        if (!isSolutionExisting) {
            System.out.println("Aucune solution trouvée.");
        }
        // Votre code doit être AVANT de ce commentaire
    }

    // Vos fonctions doivent être APRES ce commentaire
    private static int calculate(int a, int b, String op) {
        switch (op) {
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                return b != 0 ? a / b : Integer.MAX_VALUE;
            case "%":
                return b != 0 ? a % b : Integer.MAX_VALUE;
            default:
                throw new IllegalArgumentException("Opération inconnue: " + op);
        }
    }
    // Vos fonctions doivent être AVANT ce commentaire

    /***
     * Cette fonction lis et retourne le prochain int entré par l'utilisateur
     */
    private static int readNextInt() {
        boolean valid;
        int res = 0;

        do {
            valid = true;
            try {
                res = Integer.parseInt(s.nextLine().strip().replaceAll("\n", ""));
            } catch (NumberFormatException e) {
                System.out.println("Entrée non reconnue, essayez encore !");
                valid = false;
            }
        } while (!valid);
        return res;
    }

    /***
     * Cette fonction lis et retourne le prochain double entré par l'utilisateur
     */
    private static double readNextDouble() {
        double res = Double.NaN;

        do {
            try {
                res = Double.parseDouble(s.nextLine().strip().replaceAll("\n", ""));
            } catch (NumberFormatException e) {
                System.out.println("Entrée non reconnue, essayez encore !");
            }
        } while (Double.isNaN(res));
        return res;
    }

    /***
     * Cette fonction lis et retourne le prochain char entré par l'utilisateur
     */
    private static char readNextChar() {
        return s.nextLine().charAt(0);
    }

    /***
     * Cette fonction lis et retourne la ligne entrée par l'utilisateur
     */
    private static String readNextString() {
        return s.nextLine();
    }
}
